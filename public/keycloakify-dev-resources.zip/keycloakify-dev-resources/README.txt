This directory is only used in dev mode by Keycloakify
It won't be included in your final build.
Do not modify anything in this directory.